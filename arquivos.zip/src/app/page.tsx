import MovieList from "@/componentes/Movielist";

export default function Home() {
  return (
   <div>
    <MovieList />
   </div>
  );
}
