'use client';

import {useState, useEffect } from "react";
import "./index.scss";
import axios from "axios";
import MovieCard from "../MovieCard";
import { Movie } from "@/types/movie";
// import ReactLoading from 'react-loading';


export default function MovieList(){
    const [movies, setMovies] = useState<Movie[]>([]);
    // const [isLoading, setIsLoading]=useState<boolean>(true);
    useEffect(()=>{
        getMovies();
    },[])
    const getMovies = ()=>{
        axios({
            method: 'get',
            url: 'https://api.themoviedb.org/3/discover/movie',
            params:{
                api_key: '9d966a23ea34e610023a315cbea6abcf',
                language: 'pt-BR'
            }
        }).then(response =>{
            setMovies (response.data.results);
        });
    }
    
    return(
        <ul className="movie-list">
            {movies.map((movie)=>
                <MovieCard
                    key={movie.id}
                    movie={movie}
                />

            )}
            
        </ul>
    )
}